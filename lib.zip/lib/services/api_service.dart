// lib/services/api_service.dart
import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:http/io_client.dart';

/// Ubah ini jadi URL ngrok-mu (tanpa trailing slash)
const String _baseUrl = 'https://hillary-janitorial-adalyn.ngrok-free.dev';

/// Kalau ingin memaksa mengabaikan error sertifikat (development only),
/// atur ke `true`. Ingat: jangan pakai ini di production.
bool _allowBadCertificate = false;

/// Internal cached client (bisa IOClient untuk kontrol SSL)
http.Client? _clientInternal;

/// Mendapatkan client yang sesuai flag _allowBadCertificate
http.Client _getClient() {
  if (_clientInternal != null) return _clientInternal!;

  if (_allowBadCertificate) {
    // Buat HttpClient yang menerima sertifikat apapun (development)
    final ioc = HttpClient()
      ..badCertificateCallback =
          (X509Certificate cert, String host, int port) => true;
    _clientInternal = IOClient(ioc);
  } else {
    // Default safe client
    _clientInternal = http.Client();
  }
  return _clientInternal!;
}

/// Gunakan fungsi ini untuk mengubah mode insecure (dev).
/// Panggil sebelum menggunakan ApiService (mis. di main()).
void setAllowBadCertificate(bool allow) {
  _allowBadCertificate = allow;
  // rebuild client supaya efeknya dipakai segera
  _clientInternal?.close();
  _clientInternal = null;
}

/// Bersihkan client saat app ditutup (opsional)
void disposeApiService() {
  _clientInternal?.close();
  _clientInternal = null;
}

class ApiService {
  // Login
  static Future<Map<String, dynamic>> login(String nim, String password) async {
    final uri = Uri.parse('$_baseUrl/login');
    final client = _getClient();
    final response = await client.post(
      uri,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'nim': nim, 'password': password}),
    );

    return _processResponse(response);
  }

  // Ambil data mahasiswa berdasarkan NIM
  static Future<Map<String, dynamic>> getMahasiswaByNim(String nim) async {
    final uri = Uri.parse('$_baseUrl/mahasiswa/$nim');
    final client = _getClient();
    final response = await client.get(uri);
    return _processResponse(response);
  }

  // Ambil rekomendasi mata kuliah
  static Future<List<String>> getRecommendations(String nim) async {
    final uri = Uri.parse('$_baseUrl/recommend/$nim');
    final client = _getClient();
    final response = await client.get(uri);

    final parsed = _processResponse(response);
    if (parsed.containsKey('rekomendasi') && parsed['rekomendasi'] is List) {
      return List<String>.from(parsed['rekomendasi']);
    }
    return [];
  }

  /// Helper: proses response menjadi Map / lempar Exception jika error
  static Map<String, dynamic> _processResponse(http.Response response) {
    try {
      final body = response.body.isNotEmpty ? jsonDecode(response.body) : null;
      if (response.statusCode >= 200 && response.statusCode < 300) {
        if (body is Map<String, dynamic>) return body;
        // jika body bukan map, bungkus jadi map
        return {'data': body};
      } else {
        // coba ambil pesan error dari body, kalau ada
        if (body is Map<String, dynamic>) {
          final detail = body['detail'] ?? body['message'] ?? body;
          throw Exception(detail);
        } else {
          throw Exception('HTTP ${response.statusCode}: ${response.reasonPhrase}');
        }
      }
    } catch (e) {
      // jika jsonDecode gagal, lempar pesan yang berguna
      if (e is FormatException) {
        throw Exception('Invalid response format (not JSON). Status: ${response.statusCode}');
      }
      rethrow;
    }
  }
}