import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'screens/login_page.dart';
import 'screens/dashboard_page.dart';
import 'screens/rekomendasi_page.dart';
import 'screens/analysis_page.dart';
import 'screens/profile_page.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Rekomendasi Mata Kuliah',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: LandingPage(), // ✅ Mulai dari landing page
    );
  }
}

// ✅ Landing Page Baru
class LandingPage extends StatelessWidget {
  const LandingPage({super.key});
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Ilustrasi Custom - Orang dengan Kartu ID
            Container(
              width: 200,
              height: 280,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  // Badan
                  Positioned(
                    top: 100,
                    child: Container(
                      width: 100,
                      height: 80,
                      decoration: BoxDecoration(
                        color: Colors.blue[400],
                        borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(10),
                          bottomRight: Radius.circular(10),
                        ),
                      ),
                    ),
                  ),
                  
                  // Lengan kiri
                  Positioned(
                    top: 120,
                    left: 30,
                    child: Container(
                      width: 30,
                      height: 60,
                      decoration: BoxDecoration(
                        color: Color(0xFFFFD4A3),
                        borderRadius: BorderRadius.circular(15),
                      ),
                    ),
                  ),
                  
                  // Lengan kanan
                  Positioned(
                    top: 120,
                    right: 30,
                    child: Container(
                      width: 30,
                      height: 60,
                      decoration: BoxDecoration(
                        color: Color(0xFFFFD4A3),
                        borderRadius: BorderRadius.circular(15),
                      ),
                    ),
                  ),
                  
                  // Leher
                  Positioned(
                    top: 90,
                    child: Container(
                      width: 25,
                      height: 20,
                      color: Color(0xFFFFD4A3),
                    ),
                  ),
                  
                  // Kepala
                  Positioned(
                    top: 30,
                    child: Container(
                      width: 80,
                      height: 70,
                      decoration: BoxDecoration(
                        color: Color(0xFFFFD4A3),
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(40),
                          topRight: Radius.circular(40),
                          bottomLeft: Radius.circular(35),
                          bottomRight: Radius.circular(35),
                        ),
                      ),
                    ),
                  ),
                  
                  // Rambut
                  Positioned(
                    top: 20,
                    child: Container(
                      width: 85,
                      height: 40,
                      decoration: BoxDecoration(
                        color: Color(0xFF4A3C28),
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(45),
                          topRight: Radius.circular(45),
                        ),
                      ),
                    ),
                  ),
                  
                  // Mata (senyum)
                  Positioned(
                    top: 75,
                    child: Container(
                      width: 40,
                      height: 8,
                      decoration: BoxDecoration(
                        color: Color(0xFF4A3C28),
                        borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(20),
                          bottomRight: Radius.circular(20),
                        ),
                      ),
                    ),
                  ),
                  
                  // Kartu ID
                  Positioned(
                    bottom: 20,
                    child: Container(
                      width: 120,
                      height: 90,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: Colors.grey[400]!,
                          width: 3,
                        ),
                      ),
                      child: Padding(
                        padding: EdgeInsets.all(12),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Garis biru
                            Container(
                              width: 50,
                              height: 4,
                              decoration: BoxDecoration(
                                color: Colors.blue[600],
                                borderRadius: BorderRadius.circular(2),
                              ),
                            ),
                            SizedBox(height: 8),
                            // Garis abu-abu 1
                            Container(
                              width: 80,
                              height: 3,
                              decoration: BoxDecoration(
                                color: Colors.grey[300],
                                borderRadius: BorderRadius.circular(2),
                              ),
                            ),
                            SizedBox(height: 5),
                            // Garis abu-abu 2
                            Container(
                              width: 70,
                              height: 3,
                              decoration: BoxDecoration(
                                color: Colors.grey[300],
                                borderRadius: BorderRadius.circular(2),
                              ),
                            ),
                            Spacer(),
                            // Titik hijau
                            Align(
                              alignment: Alignment.centerRight,
                              child: Container(
                                width: 12,
                                height: 12,
                                decoration: BoxDecoration(
                                  color: Colors.green,
                                  shape: BoxShape.circle,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 40),
            
            // Judul
            Text(
              'Ayo Mulai!',
              style: TextStyle(
                fontSize: 32,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
            SizedBox(height: 16),
            
            // Subtitle
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 40),
              child: Text(
                'Dapatkan rekomendasi mata kuliah yang sesuai dengan performa akademik Anda',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.grey[600],
                ),
              ),
            ),
            SizedBox(height: 60),
            
            // Tombol Masuk/Daftar
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => LoginPage()),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.orange,
                padding: EdgeInsets.symmetric(horizontal: 80, vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
                elevation: 5,
              ),
              child: Text(
                'Masuk / Daftar',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
class AnalysisPage extends StatefulWidget {
  final String nim;
  AnalysisPage({required this.nim});

  @override
  AnalysisPageState createState() => AnalysisPageState();
}

class AnalysisPageState extends State<AnalysisPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  Map<String, dynamic> academicData = {};
  Map<String, dynamic> lifestyleData = {};
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    fetchData();
  }

  Future<void> fetchData() async {
    try {
      final response = await http.get(
        Uri.parse('https://annemarie-protragedy-jake.ngrok-free.dev/nilai/${widget.nim}'));// API backend
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          academicData = {
            "midterm": data['midterm_score'],
            "final": data['final_score'],
            "assignments": data['assignments_avg'],
            "quizzes": data['quizzes_avg'],
          };
          lifestyleData = {
            "sleep_hours": data['sleep_hours_per_night'],
            "stress_level": data['stress_level'],
            "checklist": {
              "Istirahat": true,
              "Olahraga": true,
              "Organisasi": false,
              "Volunteer": false,
            },
          };
          loading = false;
        });
      } else {
        throw Exception('Failed to load data');
      }
    } catch (e) {
      print("Error fetching data: $e");
    }
  }

  List<FlSpot> getSleepVsScoreSpots() {
    // Korelasi jam tidur vs performa (total_score)
    return [
      FlSpot(5, 60),
      FlSpot(6, 65),
      FlSpot(6.5, 70),
      FlSpot(7, 80),
      FlSpot(7.5, 85),
      FlSpot(8, 90),
      FlSpot(8.5, 92),
      FlSpot(9, 95),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Analisis Performa Anda'),
        bottom: TabBar(
          controller: _tabController,
          tabs: [
            Tab(text: 'Akademik'),
            Tab(text: 'Gaya Hidup'),
          ],
        ),
      ),
      body: loading
          ? Center(child: CircularProgressIndicator())
          : TabBarView(
              controller: _tabController,
              children: [
                academicTab(),
                lifestyleTab(),
              ],
            ),
    );
  }

  Widget academicTab() {
    return Padding(
      padding: EdgeInsets.all(16),
      child: Column(
        children: [
          Text(
            'Perbandingan Skor Akademik',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 200, child: lineChart()),
          SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              statBox('Midterm', academicData['midterm']),
              statBox('Final', academicData['final']),
              statBox('Assignments', academicData['assignments']),
              statBox('Quizzes', academicData['quizzes']),
            ],
          ),
          SizedBox(height: 16),
          insightBox(),
        ],
      ),
    );
  }

  Widget lifestyleTab() {
    return Padding(
      padding: EdgeInsets.all(16),
      child: Column(
        children: [
          Text(
            'Korelasi Jam Tidur & Performa',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 200, child: scatterPlot()),
          SizedBox(height: 16),
          suggestionBox(),
          SizedBox(height: 16),
          stressGauge(),
          SizedBox(height: 16),
          checklistWidget(),
        ],
      ),
    );
  }

  Widget statBox(String title, dynamic value) {
    return Container(
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.blue[50],
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          Text(title, style: TextStyle(fontWeight: FontWeight.bold)),
          Text(value.toString()),
        ],
      ),
    );
  }

  Widget insightBox() {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.yellow[100],
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        'Insight: Performa Anda cukup baik, tetap pertahankan konsistensi belajar dan istirahat yang cukup.',
      ),
    );
  }

  Widget suggestionBox() {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.green[100],
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          Text('😴 Saran: Tidur 7-8 jam per malam', style: TextStyle(fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget stressGauge() {
    double stressLevel = (lifestyleData['stress_level'] as num).toDouble();
    return Column(
      children: [
        Text('Stress Level: ${stressLevel.toInt()}/10'),
        SizedBox(
          height: 100,
          child: LinearProgressIndicator(
            value: stressLevel / 10,
            backgroundColor: Colors.grey[300],
            color: Colors.red,
          ),
        ),
      ],
    );
  }

  Widget checklistWidget() {
    Map<String, bool> checklist = Map<String, bool>.from(lifestyleData['checklist']);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: checklist.entries.map((e) {
        bool checked = e.value;
        return Row(
          children: [
            Icon(checked ? Icons.check_box : Icons.check_box_outline_blank),
            SizedBox(width: 8),
            Text(e.key),
          ],
        );
      }).toList(),
    );
  }

  LineChart lineChart() {
    return LineChart(
      LineChartData(
        titlesData: FlTitlesData(
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              getTitlesWidget: (value, meta) {
                const labels = ['Midterm', 'Final', 'Assignments', 'Quizzes'];
                if (value.toInt() >= 0 && value.toInt() < labels.length) {
                  return Text(labels[value.toInt()]);
                }
                return Text('');
              },
              interval: 1,
            ),
          ),
          leftTitles: AxisTitles(sideTitles: SideTitles(showTitles: true)),
        ),
        minX: 0,
        maxX: 3,
        minY: 0,
        maxY: 100,
        lineBarsData: [
          LineChartBarData(
            spots: [
              FlSpot(0, (academicData['midterm'] as num).toDouble()),
              FlSpot(1, (academicData['final'] as num).toDouble()),
              FlSpot(2, (academicData['assignments'] as num).toDouble()),
              FlSpot(3, (academicData['quizzes'] as num).toDouble()),
            ],
            isCurved: true,
            barWidth: 3,
            dotData: FlDotData(show: true),
          ),
        ],
      ),
    );
  }

  ScatterChart scatterPlot() {
    return ScatterChart(
      ScatterChartData(
        scatterSpots: getSleepVsScoreSpots()
            .map((e) => ScatterSpot(e.x, e.y)) // cukup ini
            .toList(),
        minX: 4,
        maxX: 10,
        minY: 50,
        maxY: 100,
        gridData: FlGridData(show: true),
        titlesData: FlTitlesData(
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              getTitlesWidget: (value, meta) => Text('${value.toInt()}h'),
              interval: 1,
            ),
          ),
          leftTitles: AxisTitles(
            sideTitles: SideTitles(showTitles: true),
          ),
        ),
      ),
    );
  }
}


class MainNavigation extends StatefulWidget {
  final Map<String, dynamic> userData;
  final String nim;

  const MainNavigation({
    super.key,
    required this.userData,
    required this.nim,
  });

  @override
  _MainNavigationState createState() => _MainNavigationState();
}

class _MainNavigationState extends State<MainNavigation> {
  int _selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    final List<Widget> pages = [
      DashboardPage(userData: widget.userData),
      RekomendasiPage(nim: widget.nim),
      AnalysisPage(nim: widget.nim),
      ProfilePage(userData: widget.userData),
    ];

    return Scaffold(
      body: pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Colors.white,
        unselectedItemColor: Colors.white70,
        backgroundColor: const Color(0xFF02796C),
        currentIndex: _selectedIndex,
        onTap: (index) {
          setState(() {
            _selectedIndex = index;
          });
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.menu_book),
            label: 'Rekomendasi',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.bar_chart),
            label: 'Analisis',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profil',
          ),
        ],
      ),
    );
  }
}
