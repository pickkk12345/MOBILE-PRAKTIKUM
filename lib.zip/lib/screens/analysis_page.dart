import 'package:flutter/material.dart';
import '../services/api_service.dart';

class AnalysisPage extends StatefulWidget {
  final String nim;
  const AnalysisPage({super.key, required this.nim});

  @override
  AnalysisPageState createState() => AnalysisPageState();
}

class AnalysisPageState extends State<AnalysisPage> {
  Map<String, dynamic>? performa;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    fetchPerforma();
  }

  Future<void> fetchPerforma() async {
    setState(() => loading = true);
    try {
      performa = await ApiService.getMahasiswaByNim(widget.nim);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal memuat data: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Analisis Performa')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : performa == null
              ? const Center(child: Text('Data performa tidak tersedia'))
              : Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Performa Akademik', style: Theme.of(context).textTheme.headlineSmall),
                      const SizedBox(height: 16),
                      // Contoh visualisasi sederhana menggunakan Row
                      ...performa!.entries.map((e) {
                        if (e.key == 'nim' || e.key == 'nama') return Container();
                        return Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(e.key),
                              Text(e.value.toString()),
                            ],
                          ),
                        );
                      }).toList(),
                    ],
                  ),
                ),
    );
  }
}
